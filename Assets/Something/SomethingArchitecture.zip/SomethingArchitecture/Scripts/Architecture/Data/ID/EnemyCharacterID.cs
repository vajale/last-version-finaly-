﻿namespace Something.SomethingArchitecture.Scripts.Architecture.Data.ID
{
    public enum EnemyCharacterID
    {
        Mummy = 0,
        Bruh = 10,
        Zombie = 20,
    }
}