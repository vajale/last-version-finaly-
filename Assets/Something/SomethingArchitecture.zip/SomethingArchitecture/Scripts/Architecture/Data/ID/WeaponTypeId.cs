﻿namespace Something.SomethingArchitecture.Scripts.Something.Weapon.Factory
{
    public enum WeaponTypeId
    {
        Rifle = 0,
        Pistol = 10,
        ShootGun = 20,
        AR01 = 30,
    }
}