﻿using Something.Scripts.Architecture.Utilities;

namespace Something.Scripts.Architecture.GameInfrastucture.Operations
{
    public class ExitGameOperation
    {
        public ExitGameOperation()
        {
            

        }
    }

    public class GameInitializeOperation
    {
        
    }
}