﻿using Something.Scripts.Architecture.GameInfrastucture.States.Interfaces;
using Something.Scripts.Something.Characters.MoveControllers.States;

namespace Something.Scripts.Architecture.GameInfrastucture.States.GameLoopStates
{
    public class GameLoopActionState : IGameState
    {
        public void Enter()
        {
            
        }

        public void Exit()
        {
            
        }
    }
}