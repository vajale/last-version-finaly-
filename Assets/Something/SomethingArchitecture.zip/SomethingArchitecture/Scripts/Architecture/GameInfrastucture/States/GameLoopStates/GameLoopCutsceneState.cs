﻿
using Something.Scripts.Architecture.GameInfrastucture.States.Interfaces;
using Something.Scripts.Something.Characters.MoveControllers.States;

namespace Something.Scripts.Architecture.GameInfrastucture.States.GameLoopStates
{
    public class GameLoopCutsceneState : IGameState
    {
        public void Enter()
        {
            
        }

        public void Exit()
        {
            
        }
    }
}