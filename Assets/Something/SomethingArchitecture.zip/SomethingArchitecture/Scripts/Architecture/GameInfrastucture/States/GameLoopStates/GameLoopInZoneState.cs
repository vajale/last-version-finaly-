﻿
using Something.Scripts.Architecture.GameInfrastucture.States.Interfaces;
using Something.Scripts.Something.Characters.MoveControllers.States;

namespace Something.Scripts.Architecture.GameInfrastucture.States.GameLoopStates
{
    public class GameLoopInZoneState : IGameState
    {
        public void Enter()
        {
            
        }

        public void Exit()
        {
            
        }
    }
}