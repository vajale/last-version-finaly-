﻿namespace Something.Scripts.Architecture.GameInfrastucture.States.Interfaces
{
    public interface IExitableState
    {
        void Exit();
    }
}