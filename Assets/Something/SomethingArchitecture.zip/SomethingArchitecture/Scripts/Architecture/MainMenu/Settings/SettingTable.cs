﻿namespace Something.Scripts.Architecture.MainMenu.Settings
{
    public class SettingTable
    {
        private GameConfig _gameConfig;
        
        public SettingTable(GameConfig gameConfig)
        {
            _gameConfig = gameConfig;
        }
        
        public void BulidContexTable()
        {
            
        }

        public void ApplySettings()
        {
            
        }
    }
}