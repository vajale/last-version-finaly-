﻿namespace Something.Scripts.Architecture.MainMenu
{
    public interface IWindow
    {
        void BulidWindow();
        void CloseWindow();
    }
}