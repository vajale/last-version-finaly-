﻿namespace Something.Scripts.Architecture.Utilities
{
    public class ScienceProgress
    {
    }
}