﻿namespace Something.Scripts.Architecture.Utilities
{
    public class WorldDataProgress
    {
        public LootProgress LootProgress { get; private set; }
        public EliminateProgress EliminateProgress { get; private set; }
    }
}