﻿using UnityEngine;

namespace Something.Scripts.Architecture.SceneInfrastucture
{
    public class GameSceneConfig : MonoBehaviour
    {
        public GameSceneConfig GetSceneData()
        {
            return null;
        }
    }
}