﻿namespace Something.Scripts.Architecture.SceneInfrastucture
{
    public interface ISceneState
    {
    
    }
}