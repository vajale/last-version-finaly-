﻿namespace Something.Scripts.Architecture.SceneInfrastucture
{
    public class SceneStateMachine
    {
    
    }
}