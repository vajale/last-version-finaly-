﻿    namespace Something.Scripts.Architecture
    {
        public static class ScenesIndex
        {
            public const string MainMenuBackground = "MainMenuBackground";
            public const string Loading = "Loading";
            public const string MainMenuView = "MainMenuView";
            public const string TestScene = "TestScene";
            public const string Initial = "Inital";
            public const string Level = "Level";
        }
    }