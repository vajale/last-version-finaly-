﻿namespace Something.Scripts.Architecture.Services.ServiceLocator
{
    public interface IService
    {
    
    }
}