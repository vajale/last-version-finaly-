﻿namespace Something.Scripts.Architecture.Utilities
{
    public interface IProgressProvider
    {
        float LoadingProgress { get; }
    }
}