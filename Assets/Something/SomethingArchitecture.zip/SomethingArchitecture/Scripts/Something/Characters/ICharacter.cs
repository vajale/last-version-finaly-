﻿namespace Something.Scripts.Something.Characters
{
    public interface ICharacter
    {
        Health Health { get; }
    }
}