﻿namespace SomethingArchitecture.Scripts.Dialoge
{
    public enum DialogeCharacterId
    {
        Случайный = 1,
        Продавец= 2,
        ФутбольныйМяч = 3,
    }
}