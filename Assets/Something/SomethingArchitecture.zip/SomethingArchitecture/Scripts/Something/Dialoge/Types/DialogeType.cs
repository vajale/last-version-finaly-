﻿namespace SomethingArchitecture.Scripts.Dialoge
{
    public enum DialogeType
    {
        Ending = 1,
        Continued = 2,
    }
}