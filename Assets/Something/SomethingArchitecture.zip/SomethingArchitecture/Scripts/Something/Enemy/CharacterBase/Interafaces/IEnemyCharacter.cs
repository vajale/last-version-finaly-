﻿using Something.Scripts.Something.Characters;

namespace Something.SomethingArchitecture.Scripts.Something.Characters.Enemy
{
    public interface IEnemyCharacter : ICharacter
    {
    }
}