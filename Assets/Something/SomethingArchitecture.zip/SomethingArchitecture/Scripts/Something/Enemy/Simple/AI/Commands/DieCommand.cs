﻿using Something.Scripts.Something.AI;

namespace Something.Scripts.Something.EnemyWave
{
    public class DieCommand : ICommand
    {
        public void Execute()
        {
            
        }

        public void Update()
        {
            throw new System.NotImplementedException();
        }

        public void Undo()
        {
            
        }
    }
}


namespace Something.Scripts.Something.AI
{
}