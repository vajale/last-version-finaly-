﻿namespace Something.Scripts.Something.AI
{
    public interface IEnemyAttacker
    {
        void Attack();
        void StopAttack();
    }
}