﻿namespace Something.Scripts.Something
{
    public interface IPresenter
    {
        void Initialize();
        void Unitialize();
    }
}
