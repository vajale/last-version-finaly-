﻿using System;

namespace Something.SomethingArchitecture.Scripts.Something.Characters.Base.Base
{
    public interface IInventoryItem
    {
        Type Type { get; }
    }
}