﻿namespace Something.SomethingArchitecture.Scripts.Architecture.Factory
{
    public interface ILoot
    {
        
    }
}