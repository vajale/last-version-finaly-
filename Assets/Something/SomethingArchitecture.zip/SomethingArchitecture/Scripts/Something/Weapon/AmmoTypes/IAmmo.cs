﻿namespace Something.Scripts.Something.Weapon.Base
{
    public interface IAmmo
    {
        int Damage { get; }
    }
}