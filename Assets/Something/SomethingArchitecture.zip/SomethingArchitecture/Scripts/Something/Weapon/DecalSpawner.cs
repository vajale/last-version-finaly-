﻿  namespace Something.Scripts.Something.Weapon
 {
     public static class DecalSpawner 
     {
         public static void SpawnDecal()
         {
        
         }
     }
 }